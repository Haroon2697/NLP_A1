"""Gym assistant package."""
